/*
 * Takada 404 - content script
 *
 * 次の2つの場合に、表示中のページを壊さず、上に専用画面（iframe）を重ねる。
 *   1. ブラウザがオフラインになったとき（window の offline イベント）
 *      → 復旧すると自動でオーバーレイが外れる
 *   2. ページ自体が 404 などのHTTPステータスで返ってきたとき（settings.js で指定）
 *      → 復旧の概念がないので自動では閉じない。「Takada off」で元のページを見られる
 */
(() => {
  if (window.top !== window) return;

  const EXT_ORIGIN = new URL(chrome.runtime.getURL("/")).origin;
  let host = null;
  let frame = null;
  let kind = null;       // "offline" | "notfound"
  let readyTimer = null;
  const dismissed = { offline: false, notfound: false }; // 「Takada off」された種類

  function removeOverlay() {
    clearTimeout(readyTimer);
    if (host) host.remove();
    host = frame = kind = null;
  }

  function showOverlay(k) {
    if (host || dismissed[k]) return;
    kind = k;

    host = document.createElement("div");
    host.setAttribute("data-takada-404", "");
    host.style.cssText =
      "all:initial;position:fixed;inset:0;z-index:2147483647;display:block;";
    const root = host.attachShadow({ mode: "closed" });

    frame = document.createElement("iframe");
    frame.allow = "autoplay; fullscreen";
    frame.style.cssText =
      "position:fixed;inset:0;width:100vw;height:100vh;border:0;background:#000;color-scheme:dark;";
    frame.src =
      chrome.runtime.getURL("offline.html") +
      `?mode=overlay&kind=${k}&url=` + encodeURIComponent(location.href);
    root.appendChild(frame);
    document.documentElement.appendChild(host);

    // ページ側のCSPでiframeが弾かれた場合に備え、一定時間内に ready が来なければ中止する。
    // オフラインのときだけは、全画面ページへ切り替えて表示を保証する。
    const myFrame = frame;
    readyTimer = setTimeout(() => {
      if (frame !== myFrame) return;
      const wasOffline = kind === "offline";
      removeOverlay();
      if (wasOffline) chrome.runtime.sendMessage({ type: "takada-fallback" }).catch(() => {});
    }, 2500);
  }

  window.addEventListener("message", (e) => {
    if (!frame || e.origin !== EXT_ORIGIN || e.source !== frame.contentWindow) return;
    const type = e.data && e.data.takada;
    if (type === "ready") clearTimeout(readyTimer);
    else if (type === "recovered") removeOverlay();
    else if (type === "dismiss") {
      dismissed[kind] = true;
      removeOverlay();
    }
  });

  window.addEventListener("offline", () => showOverlay("offline"));
  window.addEventListener("online", () => { dismissed.offline = false; });

  // このページ自体のHTTPステータス（Chrome 109+）。取得できない場合は 0。
  function checkHttpStatus() {
    try {
      const triggers = typeof TAKADA_HTTP_STATUS_TRIGGERS !== "undefined" ? TAKADA_HTTP_STATUS_TRIGGERS : [];
      const nav = performance.getEntriesByType("navigation")[0];
      if (nav && nav.responseStatus && triggers.includes(nav.responseStatus)) showOverlay("notfound");
    } catch (_) { /* 取得できなければ何もしない */ }
  }

  if (!navigator.onLine) showOverlay("offline");
  else checkHttpStatus();
})();
