# Takada 404

接続できないとき、悲しい演出画面を表示する Chrome 拡張機能（Manifest V3）。

## 導入
1. zip を展開する
2. Chrome で `chrome://extensions` を開き、右上の「デベロッパー モード」をオン
3. 「パッケージ化されていない拡張機能を読み込む」→ 展開した `takada-404` フォルダを選択

## 動作確認
- 接続エラー: `https://nonexistent.invalid/` を開く（専用画面へ切り替わる）
- 404 は対象外: `https://example.com/not-found` を開く（通常の404ページのまま）
- オフライン: DevTools → Network → Offline にするか、Wi-Fi を切る（表示中のページに専用画面が重なる）
- 404ページ: サーバーが本文付きの404を返すページ（例: 多くのサイトの「Not Found」ページ）で専用画面が重なる。「Takada off」で元のページが見られる
- デザイン確認だけしたい場合（復旧処理なし）:
  `chrome-extension://<拡張機能ID>/offline.html?preview=1&url=https://example.com/`

## カスタマイズ
- テロップ: `messages.js` の `TAKADA_MESSAGES` 配列を編集（切替間隔も同ファイル）
- 編集後は `chrome://extensions` で拡張機能を「再読み込み」
- 404などで表示するステータス: `settings.js` の `TAKADA_HTTP_STATUS_TRIGGERS`（`[]` で無効）
