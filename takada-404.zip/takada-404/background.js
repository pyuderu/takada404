/*
 * Takada 404 - background service worker
 *
 * 「本当の接続エラー」だけを拾って専用画面へ誘導する。
 * chrome.webNavigation.onErrorOccurred は、ネットワーク層で読み込みに失敗した
 * ときだけ発火する。サーバーが 404 / 500 などを返した場合（＝接続自体は成功）は
 * 発火しないので、普通の 404 ページには一切干渉しない。
 */

const OFFLINE_PAGE = chrome.runtime.getURL("offline.html");

// 「つながらない」ことを意味するエラーのみ。
// ERR_ABORTED（ユーザーの中断）、証明書エラー、ブロック系などは意図的に含めない。
const CONNECTION_ERRORS = new Set([
  "ERR_INTERNET_DISCONNECTED",
  "ERR_NETWORK_CHANGED",
  "ERR_NAME_NOT_RESOLVED",
  "ERR_NAME_RESOLUTION_FAILED",
  "ERR_CONNECTION_REFUSED",
  "ERR_CONNECTION_RESET",
  "ERR_CONNECTION_CLOSED",
  "ERR_CONNECTION_FAILED",
  "ERR_CONNECTION_TIMED_OUT",
  "ERR_TIMED_OUT",
  "ERR_ADDRESS_UNREACHABLE",
  "ERR_PROXY_CONNECTION_FAILED",
  "ERR_TUNNEL_CONNECTION_FAILED",
  "ERR_EMPTY_RESPONSE",
]);

const lastRedirect = new Map(); // tabId -> timestamp（二重発火の防止）

function offlineUrl(targetUrl) {
  return `${OFFLINE_PAGE}?mode=page&url=${encodeURIComponent(targetUrl)}`;
}

chrome.webNavigation.onErrorOccurred.addListener(
  (details) => {
    if (details.frameId !== 0) return; // メインフレームのみ（iframe の失敗は無視）
    if (!/^https?:/i.test(details.url)) return;

    const code = String(details.error || "").replace(/^net::/, "");
    if (!CONNECTION_ERRORS.has(code)) return;

    const now = Date.now();
    if (now - (lastRedirect.get(details.tabId) || 0) < 1500) return;
    lastRedirect.set(details.tabId, now);

    chrome.tabs
      .update(details.tabId, { url: offlineUrl(details.url) })
      .catch(() => {}); // タブが既に閉じられた場合など
  },
  { url: [{ schemes: ["http", "https"] }] }
);

chrome.tabs.onRemoved.addListener((tabId) => lastRedirect.delete(tabId));

// content.js から：オーバーレイ表示に失敗したページ（CSP等）は全画面に切り替える
chrome.runtime.onMessage.addListener((msg, sender) => {
  if (msg && msg.type === "takada-fallback" && sender.tab && sender.url) {
    if (!/^https?:/i.test(sender.url)) return;
    chrome.tabs.update(sender.tab.id, { url: offlineUrl(sender.url) }).catch(() => {});
  }
});
