/*
 * Takada 404 - 専用画面のロジック
 *  mode=page    : 接続エラーで開かれた全画面ページ（復旧したら元のURLへ戻る）
 *  mode=overlay : 表示中のページに重ねた iframe（復旧したらオーバーレイを外すだけ）
 *  kind=notfound: HTTP 404 等のページに重ねた場合。復旧の概念がないので自動では閉じない
 *  preview=1    : 動作・デザイン確認用。復旧処理を行わない
 */
(() => {
  "use strict";

  /* ---------- パラメータ ---------- */
  const params = new URLSearchParams(location.search);
  const mode = params.get("mode") === "overlay" ? "overlay" : "page";
  const notFound = params.get("kind") === "notfound";
  const preview = params.get("preview") === "1";
  const noRecovery = preview || notFound;

  let targetUrl = "";
  try {
    const u = new URL(params.get("url") || "");
    if (u.protocol === "http:" || u.protocol === "https:") targetUrl = u.href; // javascript: 等は無視
  } catch (_) { /* 未指定 */ }

  const $ = (id) => document.getElementById(id);
  const video = $("video");
  const telop = $("telop");
  const hint = $("hint");
  const muteBtn = $("muteBtn");
  const offBtn = $("offBtn");

  const post = (takada) => {
    if (mode === "overlay") parent.postMessage({ takada }, "*");
  };

  /* ---------- ステータス表示 ---------- */
  if (notFound && !targetUrl) $("status").textContent = "ページが見つかりません";
  if (targetUrl) {
    try {
      const h = new URL(targetUrl).host;
      $("status").textContent = notFound ? `${h} ― ページが見つかりません` : `${h} に接続できません`;
    } catch (_) {}
  }

  /* ---------- 動画 ---------- */
  let isOff = false;
  let autoMuted = false; // 自動再生制限のために一時的にミュートしている状態

  function refreshMuteUi() {
    muteBtn.textContent = video.muted ? "ミュート解除" : "ミュート";
    muteBtn.setAttribute("aria-pressed", String(video.muted));
  }

  function hideHint() {
    if (hint.hidden) return;
    hint.classList.add("fade");
    setTimeout(() => { hint.hidden = true; }, 800);
  }

  async function startVideo() {
    video.muted = false;
    try {
      await video.play();                 // まず音あり再生を試す
    } catch (_) {
      video.muted = true;                 // 自動再生制限 → ミュートで再生し、操作を待つ
      autoMuted = true;
      hint.hidden = false;
      try { await video.play(); } catch (_) { /* 再生不可でも画面は維持 */ }
    }
    refreshMuteUi();
  }

  video.addEventListener("loadeddata", () => video.classList.add("ready"), { once: true });

  // 最初のユーザー操作で音を出す（ミュートボタン等の操作は対象外）
  function onFirstGesture(e) {
    if (!autoMuted || $("controls").contains(e.target) || !$("modal").hidden) return;
    autoMuted = false;
    video.muted = false;
    refreshMuteUi();
    hideHint();
  }
  document.addEventListener("pointerdown", onFirstGesture);
  document.addEventListener("keydown", onFirstGesture);

  muteBtn.addEventListener("click", () => {
    autoMuted = false;
    video.muted = !video.muted;
    refreshMuteUi();
    hideHint();
  });

  // 見えているタブだけで再生（複数タブで同時に音が重なるのを防ぐ）
  document.addEventListener("visibilitychange", () => {
    if (isOff) return;
    if (document.hidden) video.pause();
    else video.play().catch(() => {});
  });

  /* ---------- ランダムメッセージ ---------- */
  const messages = Array.isArray(TAKADA_MESSAGES) ? TAKADA_MESSAGES.filter(Boolean) : [];
  const FADE_MS = 1400;
  const INTERVAL_MS = Math.max(4000, Number(TAKADA_MESSAGE_INTERVAL_MS) || 20000);
  let lastIndex = -1;
  let telopTimer = null;

  function pickIndex() {
    if (messages.length <= 1) return 0;
    let i;
    do { i = Math.floor(Math.random() * messages.length); } while (i === lastIndex);
    return i;
  }

  function showNext() {
    if (isOff || messages.length === 0) return;
    const swap = () => {
      lastIndex = pickIndex();
      telop.textContent = messages[lastIndex];
      void telop.offsetWidth;
      telop.classList.add("show");
      telopTimer = setTimeout(showNext, INTERVAL_MS);
    };
    if (telop.classList.contains("show")) {
      telop.classList.remove("show");
      telopTimer = setTimeout(swap, FADE_MS);   // フェードアウト → 差し替え → フェードイン
    } else {
      swap();
    }
  }

  /* ---------- Takada off ---------- */
  const modal = $("modal");
  const offScreen = $("offScreen");

  function openModal() {
    modal.hidden = false;
    $("cancelOff").focus();
  }
  function closeModal() {
    modal.hidden = true;
    offBtn.focus();
  }

  function takadaOff() {
    modal.hidden = true;
    if (mode === "overlay") {         // 重ねていた場合は閉じて元のページを見せる
      video.pause();
      post("dismiss");
      return;
    }
    isOff = true;
    clearTimeout(telopTimer);
    video.pause();
    $("scene").hidden = true;
    offScreen.hidden = false;
    $("onBtn").focus();
  }

  function takadaOn() {
    isOff = false;
    offScreen.hidden = true;
    $("scene").hidden = false;
    telop.classList.remove("show");
    startVideo();
    showNext();
  }

  offBtn.addEventListener("click", openModal);
  $("cancelOff").addEventListener("click", closeModal);
  $("confirmOff").addEventListener("click", takadaOff);
  $("onBtn").addEventListener("click", takadaOn);
  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape" && !modal.hidden) closeModal();
  });
  modal.addEventListener("pointerdown", (e) => { if (e.target === modal) closeModal(); });

  /* ---------- 接続の確認と復旧 ---------- */
  const POLL_MS = 4000;
  const PROBE_TIMEOUT_MS = 7000;
  const LOOP_GUARD_MS = 20000;
  let probing = false;
  let recovering = false;

  // 元のURLへ実際に到達できるかを確認（no-cors：中身は読まず、応答の有無だけを見る）。
  // 404 や 500 でも「サーバーに届いた」ので到達成功とみなす。
  async function reachable() {
    if (!navigator.onLine) return false;
    if (!targetUrl) return true;
    const ctrl = new AbortController();
    const t = setTimeout(() => ctrl.abort(), PROBE_TIMEOUT_MS);
    try {
      await fetch(targetUrl, {
        method: "HEAD", mode: "no-cors", cache: "no-store",
        credentials: "omit", signal: ctrl.signal,
      });
      return true;
    } catch (_) {
      return false;
    } finally {
      clearTimeout(t);
    }
  }

  function recover() {
    if (recovering) return;
    if (mode === "overlay") {
      recovering = true;
      video.pause();
      post("recovered");              // 元のページは壊さず、重ねていた画面を外すだけ
      return;
    }
    if (!targetUrl) return;
    // 復旧直後にまた失敗 → 専用画面 → 復旧…の無限ループを避ける
    const last = Number(sessionStorage.getItem("takada:lastRecover") || 0);
    if (Date.now() - last < LOOP_GUARD_MS) return;
    sessionStorage.setItem("takada:lastRecover", String(Date.now()));
    recovering = true;
    video.pause();
    location.replace(targetUrl);      // 履歴を増やさず元のページを再読み込み
  }

  async function check() {
    if (probing || recovering || noRecovery) return;
    probing = true;
    try {
      if (await reachable()) recover();
    } finally {
      probing = false;
    }
  }

  setInterval(check, POLL_MS);
  window.addEventListener("online", check);

  /* ---------- 起動 ---------- */
  startVideo();
  setTimeout(showNext, 1800);         // 動画のフェードインに少し遅れてテロップ開始
  post("ready");
})();
